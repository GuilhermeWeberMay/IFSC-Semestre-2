public interface IAgendavel {
    void agendarConsulta(Consulta consulta);
}
