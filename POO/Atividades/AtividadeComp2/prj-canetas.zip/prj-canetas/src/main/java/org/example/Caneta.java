package org.example;

public class Caneta {
    public String cor;
    public float espessura;
    public boolean tampada;
    public int carga;
}
