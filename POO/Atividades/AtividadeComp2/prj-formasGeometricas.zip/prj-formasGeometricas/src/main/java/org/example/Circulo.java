package org.example;

public class Circulo {
    public double raio;

    public void desenhar() {
        System.out.println("Desenhando um circulo");
    }
}
