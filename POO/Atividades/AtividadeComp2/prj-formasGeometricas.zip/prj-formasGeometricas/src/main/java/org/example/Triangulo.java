package org.example;

public class Triangulo {
    public double base;
    public double altura;

    public void desenhar() {
        System.out.println("Desenhando um triângulo");
    }
}
