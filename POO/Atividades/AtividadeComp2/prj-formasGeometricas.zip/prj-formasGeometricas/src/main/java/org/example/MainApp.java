package org.example;
public class MainApp {
    public static void main(String[] args) {
        // Instanciação do Objeto Circulo
        Circulo circulo = new Circulo();
        // Instanciação do Objeto Triangulo
        Triangulo triangulo = new Triangulo();
        // Instanciação do Objeto Quadrado
        Quadrado quadrado = new Quadrado();

        circulo.desenhar();
        triangulo.desenhar();
        quadrado.desenhar();
    }
}