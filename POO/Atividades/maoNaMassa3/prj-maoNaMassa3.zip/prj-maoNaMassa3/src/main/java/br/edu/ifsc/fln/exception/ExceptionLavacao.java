package br.edu.ifsc.fln.exception;

public class ExceptionLavacao extends Exception {
    public ExceptionLavacao(String message) {
        super(message);
    }
    public ExceptionLavacao() {
    }
}
